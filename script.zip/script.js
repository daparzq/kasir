const menuToggle = document.querySelector(".menu input");
const nav = document.querySelector("body nav ul");

menuToggle.addEventListener("click", function () {
  nav.classList.toggle("slide");
});

var icon = document.getElementById("icon");

localStorage.setItem("theme", "dark");

let localData = localStorage.getItem("theme");

if (localData == "dark") {
  icon.src = "image/sun.png";
  document.body.classList.remove("light-theme");
} else if (localData == "light") {
  icon.src = "image/moon.png";
  document.body.classList.remove("light-theme");
}

icon.onclick = function () {
  document.body.classList.toggle("light-theme");
  if (document.body.classList.contains("light-theme")) {
    icon.src = "image/moon.png";
    localStorage.setItem("theme", "light");
  } else {
    icon.src = "image/sun.png";
    localStorage.setItem("theme", "dark");
  }
};
